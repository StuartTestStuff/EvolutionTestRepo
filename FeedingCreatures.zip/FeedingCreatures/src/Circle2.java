public class Circle2 {
    public void draw () {
        MainClass.processing.line(1, 1, 1, 50);
    }
}
